 class coin() {
 
 }